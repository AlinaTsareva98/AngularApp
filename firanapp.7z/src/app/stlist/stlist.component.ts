import { Component, OnInit } from '@angular/core';
import {Student} from '../Student';
import {StservisService} from '../stservis.service';
@Component({
  selector: 'app-stlist',
  templateUrl: './stlist.component.html',
  styleUrls: ['./stlist.component.css']
})
export class StlistComponent implements OnInit {

  constructor(private serv: StservisService) { }

  ngOnInit(): void {
    this.stmas=this.serv.getStudents();
  }

  stmas:Student [];

}
