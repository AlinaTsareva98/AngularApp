import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StlistComponent } from './stlist.component';

describe('StlistComponent', () => {
  let component: StlistComponent;
  let fixture: ComponentFixture<StlistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StlistComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
