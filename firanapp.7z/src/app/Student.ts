export interface Student {
    FIO:string;
    phoneNumber:string;
}