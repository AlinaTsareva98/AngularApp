import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InpstudentComponent } from './inpstudent.component';

describe('InpstudentComponent', () => {
  let component: InpstudentComponent;
  let fixture: ComponentFixture<InpstudentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InpstudentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InpstudentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
