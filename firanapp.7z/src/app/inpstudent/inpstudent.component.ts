import { Component, OnInit, Input} from '@angular/core';
import{Student} from '../Student';
import {StservisService} from '../stservis.service'
@Component({
  selector: 'app-inpstudent',
  templateUrl: './inpstudent.component.html',
  styleUrls: ['./inpstudent.component.css']
})
export class InpstudentComponent implements OnInit {

  constructor(public serv:StservisService) { }

  ngOnInit(): void {
  }

  st:Student = {FIO:"", phoneNumber:""};
  add(){
    this.serv.addst(this.st);
  };

}

