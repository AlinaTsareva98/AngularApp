import { TestBed } from '@angular/core/testing';

import { StservisService } from './stservis.service';

describe('StservisService', () => {
  let service: StservisService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(StservisService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
