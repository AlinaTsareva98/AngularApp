import { Injectable } from '@angular/core';
import {Student} from './Student';
@Injectable({
  providedIn: 'root'
})
export class StservisService {

  constructor() { }
  stmas: Student []=[];
  getStudents (): Student [] {
    return this.stmas;
  };
  addst (st:Student) {
    this.stmas.push(st);
  }
}
